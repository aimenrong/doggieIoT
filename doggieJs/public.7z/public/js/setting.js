var brokerHost = "localhost";
var brokerPort = 1884;

function saveSetting(host, port) {
	brokerHost = host;
	brokerPort = port;
}